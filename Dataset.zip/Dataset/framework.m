function out = model
%
% comsol.m


import com.comsol.model.*
import com.comsol.model.util.*

model = ModelUtil.create('Model');

model.modelPath('...');

path=sprintf(char('...'));
porosityfile=sprintf(char('...'));
perfile=sprintf(char('...'));

model.component.create('comp1', true);

model.component('comp1').geom.create('geom1', 2);

model.component('comp1').mesh.create('mesh1');

model.component('comp1').physics.create('br', 'Brinkman', 'geom1');

model.study.create('std1');
model.study('std1').create('stat', 'Stationary');
model.study('std1').feature('stat').activate('br', true);

model.component('comp1').geom('geom1').lengthUnit('mm');
model.component('comp1').geom('geom1').run;
model.component('comp1').geom('geom1').create('r1', 'Rectangle');
model.component('comp1').geom('geom1').feature('r1').set('size', [2 1.6]);
model.component('comp1').geom('geom1').run('r1');
model.component('comp1').geom('geom1').create('ls1', 'LineSegment');
model.component('comp1').geom('geom1').feature('ls1').set('specify1', 'coord');
model.component('comp1').geom('geom1').feature('ls1').set('coord1', [0 0.6]);
model.component('comp1').geom('geom1').feature('ls1').set('specify2', 'coord');
model.component('comp1').geom('geom1').feature('ls1').set('coord2', [2 0.6]);
model.component('comp1').geom('geom1').run('fin');

model.save(path);
model.component('comp1').func.create('int1', 'Interpolation');
model.component('comp1').func('int1').set('source', 'file');
model.component('comp1').func('int1').set('filename', porosityfile);%update porosity file i i=i+1
model.component('comp1').func('int1').setIndex('funcs', 'por', 0, 0);
model.component('comp1').func('int1').set('defvars', true);
model.component('comp1').func('int1').set('interp', 'linear');
model.component('comp1').func('int1').set('argunit', 'mm');
model.component('comp1').func('int1').importData;

model.component('comp1').func.create('int2', 'Interpolation');
model.component('comp1').func('int2').set('source', 'file');
model.component('comp1').func('int2').set('filename', perfile);%update porosity file i i=i+1
model.component('comp1').func('int2').setIndex('funcs', 'per', 0, 0);
model.component('comp1').func('int2').set('defvars', true);
model.component('comp1').func('int2').set('interp', 'linear');
model.component('comp1').func('int2').set('argunit', 'mm');
model.component('comp1').func('int2').importData;

model.save(path);

%model.component('comp1').physics('br').prop('PhysicalModelProperty').set('StokesFlowProp', false);
model.component('comp1').physics('br').feature('fmp1').set('rho_mat', 'userdef');
model.component('comp1').physics('br').feature('fmp1').set('rho', 997);
model.component('comp1').physics('br').feature('fmp1').set('mu_mat', 'userdef');
model.component('comp1').physics('br').feature('fmp1').set('mu', 0.001);
model.component('comp1').physics('br').feature('fmp1').set('epsilon_p_mat', 'userdef');
model.component('comp1').physics('br').feature('fmp1').set('epsilon_p', 'por');
model.component('comp1').physics('br').feature('fmp1').set('kappa_mat', 'userdef');
model.component('comp1').physics('br').feature('fmp1').set('kappa', {'per' '0' '0' '0' 'per' '0' '0' '0' 'per'});


model.component('comp1').physics('br').create('inl1', 'InletBoundary', 1);
model.component('comp1').physics('br').feature('inl1').selection.set([3]);
model.component('comp1').physics('br').feature('inl1').set('BoundaryCondition', 'FullyDevelopedFlow');
model.component('comp1').physics('br').feature('inl1').set('Uavfdf', '6.67e-4');
model.component('comp1').physics('br').create('out1', 'OutletBoundary', 1);
model.component('comp1').physics('br').feature('out1').selection.set([6 7]);


model.component('comp1').mesh('mesh1').autoMeshSize(1);
model.component('comp1').mesh('mesh1').run;
model.save(path);
model.sol.create('sol1');
model.sol('sol1').study('std1');

model.study('std1').feature('stat').set('notlistsolnum', 1);
model.study('std1').feature('stat').set('notsolnum', '1');
model.study('std1').feature('stat').set('listsolnum', 1);
model.study('std1').feature('stat').set('solnum', '1');

model.sol('sol1').create('st1', 'StudyStep');
model.sol('sol1').feature('st1').set('study', 'std1');
model.sol('sol1').feature('st1').set('studystep', 'stat');
model.sol('sol1').create('v1', 'Variables');
model.sol('sol1').feature('v1').set('control', 'stat');
model.sol('sol1').create('s1', 'Stationary');
model.sol('sol1').feature('s1').feature('aDef').set('cachepattern', true);
model.sol('sol1').feature('s1').create('fc1', 'FullyCoupled');
model.sol('sol1').feature('s1').feature('fc1').set('initstep', 0.01);
model.sol('sol1').feature('s1').feature('fc1').set('minstep', 1.0E-6);
model.sol('sol1').feature('s1').feature('fc1').set('dtech', 'auto');
model.sol('sol1').feature('s1').feature('fc1').set('maxiter', 100);
model.sol('sol1').feature('s1').create('d1', 'Direct');
model.sol('sol1').feature('s1').feature('d1').set('linsolver', 'pardiso');
model.sol('sol1').feature('s1').feature('fc1').set('linsolver', 'd1');
model.sol('sol1').feature('s1').feature('fc1').set('initstep', 0.01);
model.sol('sol1').feature('s1').feature('fc1').set('minstep', 1.0E-6);
model.sol('sol1').feature('s1').feature('fc1').set('dtech', 'auto');
model.sol('sol1').feature('s1').feature('fc1').set('maxiter', 100);
model.sol('sol1').feature('s1').feature.remove('fcDef');
model.sol('sol1').attach('std1');
model.sol('sol1').feature('s1').feature('d1').set('linsolver', 'mumps');
model.result.create('pg1', 'PlotGroup2D');
model.result('pg1').label('Velocity (br)');
model.result('pg1').set('frametype', 'spatial');
model.result('pg1').set('data', 'dset1');
model.result('pg1').feature.create('surf1', 'Surface');
model.result('pg1').feature('surf1').label('Surface');
model.result('pg1').feature('surf1').set('data', 'parent');
model.result.create('pg2', 'PlotGroup2D');
model.result('pg2').label('Pressure (br)');
model.result('pg2').set('frametype', 'spatial');
model.result('pg2').set('data', 'dset1');
model.result('pg2').feature.create('con1', 'Contour');
model.result('pg2').feature('con1').label('Contour');
model.result('pg2').feature('con1').set('expr', 'p');
model.result('pg2').feature('con1').set('number', 40);
model.result('pg2').feature('con1').set('data', 'parent');

model.sol('sol1').runAll;

model.result('pg1').run;
model.result.export.create('data1', 'Data');
model.result.export('data1').set('expr', {'u'});
model.result.export('data1').set('descr', {'Velocity field, x component'});
model.result.export('data1').set('unit', {'m/s'});
model.result.export('data1').set('filename', 'v.vx');
model.result.export('data1').set('location', 'grid');
model.result.export('data1').set('gridx2', 'range(0,0.01,2)');
model.result.export('data1').set('gridy2', 'range(0.005,0.01,1.595)');
model.result.export('data1').run;

model.result.export('data1').set('expr', {'v'});
model.result.export('data1').set('descr', {'Velocity field, y component'});
model.result.export('data1').set('unit', {'m/s'});
model.result.export('data1').set('filename', 'v.vy');
model.result.export('data1').set('gridx2', 'range(0.005,0.01,1.995)');
model.result.export('data1').set('gridy2', 'range(0,0.01,1.6)');
model.result.export('data1').run;
model.result.export('data1').set('filename', 'coor.txt');
model.result.export('data1').set('gridx2', 'range(0.005,0.01,1.995)');
model.result.export('data1').set('gridy2', 'range(0.005,0.01,1.595)');
model.result.export('data1').run;

model.save(path);

%velocityx
%save file
fid=fopen('velocitystep1.vx','wt');
velocityx=load('v.vx'); 
fprintf(fid,'%g\n',velocityx(:,3));
fclose(fid);

%velocityy
%save file
fid=fopen('velocitystep1.vy','wt');
velocityy=load('v.vy');  
fprintf(fid,'%g\n',velocityy(:,3));
fclose(fid);

system('Crunch.exe');


n=1000;
timestep=0.05;
spatial=0.05;
for i=2:n

k0=1e2;
k1=1e-14;

%%porosityi.txt per.txt
name=sprintf(char('porosity%d.tec'),i-1);
fid = fopen(name);%porosity(i-1).tec
[~] = fgetl(fid);% read the second line of data file
str = fgetl(fid);
pat='"';% get the number of the variables
o1 = regexpi(str,pat,'start');
var_num = length(o1)/2;
strformat = repmat('%f',1,var_num);% read the data for polosity(i-1).tec
tecplot = textscan(fid,strformat,'headerlines',1);
tecplot = cell2mat(tecplot);
fclose(fid);
coordinate=load('coor.txt');
por=[coordinate(:,1:2),tecplot(:,4)];
per=[coordinate(:,1:2),tecplot(:,4)];
[m,n]=size(por);
for x=1:1:m
   if por(x,3)>=0.999
      per(x,3)=k0;
   else
      per(x,3)=k1*(por(x,3)^3)/((1-por(x,3))^2);
   end
end



porosityfile=sprintf(char('porosity%d.txt'),i);
perfile=sprintf(char('per%d.txt'),i);
fid=fopen(porosityfile,'wt');
fid2=fopen(perfile,'wt');
for x=1:1:m  
         for y=1:1:n 
            if y==n  
             fprintf(fid,'%.7e\n',por(x,y));  
             fprintf(fid2,'%.7e\n',per(x,y));
          else  
           fprintf(fid,'%.7e\t',por(x,y));  
           fprintf(fid2,'%.7e\t',per(x,y));
         end 
      end 
    end 
fclose(fid); 
fclose(fid2); 

porosityfile=sprintf(char('porosity%d.txt'),i);
perfile=sprintf(char('per%d.txt'),i);

model.component('comp1').func('int1').discardData;
model.component('comp1').func('int1').set('filename', porosityfile);%update porosity file i i=i+1
model.component('comp1').func('int1').setIndex('funcs', 'por', 0, 0);
model.component('comp1').func('int1').set('defvars', true);
model.component('comp1').func('int1').set('argunit', 'mm');
model.component('comp1').func('int1').importData;

model.component('comp1').func('int2').discardData;
model.component('comp1').func('int2').set('filename', perfile);%update porosity file i i=i+1
model.component('comp1').func('int2').setIndex('funcs', 'per', 0, 0);
model.component('comp1').func('int2').set('defvars', true);
model.component('comp1').func('int2').set('argunit', 'mm');
model.component('comp1').func('int2').importData;



newstudy=sprintf(char('std%d'),i);
newsolution=sprintf(char('sol%d'),i);
oldstudy=sprintf(char('std%d'),i-1);

model.study.create(newstudy);%new study
model.study(newstudy).create('stat', 'Stationary');
model.study(newstudy).feature('stat').activate('br', true);

%model.study(newstudy).feature('stat').set('initstudy', oldstudy);
%model.study(newstudy).feature('stat').set('initmethod', 'sol');
%model.study(newstudy).feature('stat').set('usesol', true);
%model.study(newstudy).feature('stat').set('notsolmethod', 'sol');
%model.study(newstudy).feature('stat').set('notstudy', oldstudy);% set the solution of study1 as the initial data for study2

model.sol.create(newsolution);
model.sol(newsolution).study(newstudy);


model.study(newstudy).feature('stat').set('notlistsolnum', 1);
model.study(newstudy).feature('stat').set('notsolnum', '1');
model.study(newstudy).feature('stat').set('listsolnum', 1);
model.study(newstudy).feature('stat').set('solnum', '1');



model.sol(newsolution).create('st1', 'StudyStep');
model.sol(newsolution).feature('st1').set('study', newstudy);
model.sol(newsolution).feature('st1').set('studystep', 'stat');
model.sol(newsolution).create('v1', 'Variables');
model.sol(newsolution).feature('v1').set('control', 'stat');
model.sol(newsolution).create('s1', 'Stationary');
model.sol(newsolution).feature('s1').create('fc1', 'FullyCoupled');
model.sol(newsolution).feature('s1').feature('fc1').set('initstep', 0.01);
model.sol(newsolution).feature('s1').feature('fc1').set('minstep', 1.0E-6);
model.sol(newsolution).feature('s1').feature('fc1').set('dtech', 'auto');
model.sol(newsolution).feature('s1').feature('fc1').set('maxiter', 100);
model.sol(newsolution).feature('s1').create('d1', 'Direct');
model.sol(newsolution).feature('s1').feature('d1').set('linsolver', 'pardiso');
model.sol(newsolution).feature('s1').feature('d1').set('pardreorder', 'mmd');
model.sol(newsolution).feature('s1').feature('fc1').set('linsolver', 'd1');
model.sol(newsolution).feature('s1').feature('fc1').set('initstep', 0.01);
model.sol(newsolution).feature('s1').feature('fc1').set('minstep', 1.0E-6);
model.sol(newsolution).feature('s1').feature('fc1').set('dtech', 'auto');
model.sol(newsolution).feature('s1').feature('fc1').set('maxiter', 100);
model.sol(newsolution).feature('s1').feature.remove('fcDef');
model.sol(newsolution).attach(newstudy);

picture1=sprintf(char('pg%d'),2*i-1);
picture2=sprintf(char('pg%d'),2*i);
newbrvel=sprintf(char('Velocity (br) %d'),i-1);
newbrpre=sprintf(char('Pressure (br) %d'),i-1);
newset=sprintf(char('dset%d'),i-1);

model.result.create(picture1, 'PlotGroup2D');


model.result(picture1).label(newbrvel);
model.result(picture1).set('data', newset);
model.result(picture1).set('frametype', 'spatial');
model.result(picture1).set('data', newset);
model.result(picture1).feature.create('surf1', 'Surface');
model.result(picture1).feature('surf1').label('Surface');
model.result(picture1).feature('surf1').set('data', 'parent');
model.result.create(picture2, 'PlotGroup2D');
model.result(picture2).label(newbrpre);
model.result(picture2).set('data', newset);
model.result(picture2).set('frametype', 'spatial');
model.result(picture2).set('data', newset);
model.result(picture2).feature.create('con1', 'Contour');
model.result(picture2).feature('con1').label('Contour');
model.result(picture2).feature('con1').set('expr', 'p');
model.result(picture2).feature('con1').set('number', 40);
model.result(picture2).feature('con1').set('data', 'parent');

model.sol(newsolution).feature('s1').feature('d1').set('linsolver', 'mumps');
model.sol(newsolution).runAll;

model.result(picture1).run;

exportname1=sprintf(char('velocityxstep%d.txt'),i);  
exportname2=sprintf(char('velocityystep%d.txt'),i);

%export data
model.result.export('data1').set('expr', {'u'});
model.result.export('data1').set('descr', {'Velocity field, x component'});
model.result.export('data1').set('unit', {'m/s'});
model.result.export('data1').set('data', newset);
model.result.export('data1').set('filename', exportname1);% save file  step i i=i+1
model.result.export('data1').set('location', 'grid');
model.result.export('data1').set('gridx2', 'range(0,0.01,2)');
model.result.export('data1').set('gridy2', 'range(0.005,0.01,1.595)');
model.result.export('data1').run;

model.result.export('data1').set('expr', {'v'});
model.result.export('data1').set('descr', {'Velocity field, y component'});
model.result.export('data1').set('unit', {'m/s'});
model.result.export('data1').set('filename', exportname2);%save file step i i=i+1
model.result.export('data1').set('gridx2', 'range(0.005,0.01,1.995)');
model.result.export('data1').set('gridy2', 'range(0,0.01,1.6)');
model.result.export('data1').run;

model.save(path);


velocitystepvx=sprintf(char('velocitystep%d.vx'),i);
velocitystepvy=sprintf(char('velocitystep%d.vy'),i);
exportname1=sprintf(char('velocityxstep%d.txt'),i);  
exportname2=sprintf(char('velocityystep%d.txt'),i);

fid=fopen(velocitystepvx,'wt');
velocityx=load(exportname1); 

fprintf(fid,'%g\n',velocityx(:,3));
fclose(fid);

%velocityy
%save file
fid=fopen(velocitystepvy,'wt');
velocityy=load(exportname2); 
fprintf(fid,'%g\n',velocityy(:,3));
fclose(fid);


%change PestControl.ant
fidr=fopen('PestControl.ant','rt');
fidw=fopen('PestControl1.ant','wt');
while ~feof(fidr)
s=fgets(fidr);
control1=sprintf(char('step%d.in'),i-1);
control2=sprintf(char('step%d.in'),i);
s=strrep(s,control1,control2);
fprintf(fidw,'%s',s);
end
fclose(fidr);
fclose(fidw);
delete('PestControl.ant');
eval(['!rename',',PestControl1.ant' ',PestControl.ant']);

%revise stepi.in
fidr=fopen('input.in','rt');
filenameinput1=sprintf(char('step%d.in'),i);
fidw=fopen(filenameinput1,'wt');
while ~feof(fidr)
s=fgets(fidr);
replace1=sprintf(char('step%d.rst'),i);
replace2=sprintf(char('step%d.rst'),i-1);
replace3=sprintf(char('velocitystep%d'),i);
replace4=sprintf(char('spatial_profile  %d'),timestep);

s=strrep(s,'step2.rst',replace1);
s=strrep(s,'step1.rst',replace2);
s=strrep(s,'velocitystep',replace3);
s=strrep(s,'spatial_profile',replace4);

fprintf(fidw,'%s',s);
end
fclose(fidr);
fclose(fidw);

timestep=timestep+spatial;

system('Crunch.exe');

end
out = model;



